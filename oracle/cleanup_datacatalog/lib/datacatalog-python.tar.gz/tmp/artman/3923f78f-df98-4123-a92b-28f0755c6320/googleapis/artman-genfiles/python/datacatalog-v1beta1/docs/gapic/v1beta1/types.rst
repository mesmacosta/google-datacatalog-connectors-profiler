Types for Google Cloud Data Catalog API Client
==============================================

.. automodule:: google.cloud.datacatalog_v1beta1.types
    :members: