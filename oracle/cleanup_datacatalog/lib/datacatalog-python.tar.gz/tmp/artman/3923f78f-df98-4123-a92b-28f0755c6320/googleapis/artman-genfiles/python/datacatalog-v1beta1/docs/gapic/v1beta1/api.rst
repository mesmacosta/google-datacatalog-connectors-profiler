Client for Google Cloud Data Catalog API
========================================

.. automodule:: google.cloud.datacatalog_v1beta1
    :members:
    :inherited-members: